const userData=require('./user');
module.exports={
	userData:userData
}